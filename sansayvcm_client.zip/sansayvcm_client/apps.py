from django.apps import AppConfig


class SansayvcmClientConfig(AppConfig):
    name = 'sansayvcm_client'
